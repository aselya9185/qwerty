from django.contrib import admin
from . models import City
#admin sk - 88888888

# Register your models here.
admin.site.register(City)